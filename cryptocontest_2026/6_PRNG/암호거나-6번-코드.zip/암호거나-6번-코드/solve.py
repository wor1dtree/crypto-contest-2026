# ============================================================
# [단계 설명]
# 1. summary의 정의로부터 관계식을 세운다:
#       summary_i × 2^20 + e_i = (scale_i × d + offset_i) mod n
#    e_i는 잘려나간 하위 20비트이므로 0 ≤ e_i < 2^20
#
# 2. row 0의 식에서 d를 e0로 표현한 뒤 row 1 식에 대입해 d를 소거한다.
#    결과적으로 e1 = A × e0 - C (mod n) 형태로 정리된다.
#
# 3. e0를 [0, 2^20) 범위에서 전수조사하면서 e1도 같은 범위에 드는 쌍을 찾는다.
#    이 조건을 동시에 만족하는 쌍은 단 1개만 존재한다.
#
# 4. 찾은 e0로 d를 계산하고, 나머지 row 2~5에 대입해 모두 일치하면 d 확정.
#
# [의사코드]
# S_i ← summary_i × 2^20
# inv_s0 ← scale_0^{-1} mod n
# A ← scale_1 × inv_s0 mod n
# C ← S_1 - A × (S_0 - offset_0) - offset_1 mod n
#
# for e0 in range(2^20):
#     e1 ← (A × e0 - C) mod n
#     if 0 ≤ e1 < 2^20:
#         d_cand ← inv_s0 × (S_0 + e0 - offset_0) mod n
#         if ∀i∈{2..5}: ⌊(scale_i × d_cand + offset_i) mod n / 2^20⌋ = summary_i:
#             return d_cand
# ============================================================

def mod_inverse(a, m):
    g, x, _ = extended_gcd(a % m, m)
    if g != 1:
        raise ValueError("역원 없음")
    return x % m

def extended_gcd(a, b):
    if a == 0:
        return b, 0, 1
    g, x, y = extended_gcd(b % a, a)
    return g, y - (b // a) * x, x

n = 0x2b674bdfd6fc4ba4ba751d

data = [
    (0, 0x5be8f8855cda8bdb723a9,  0x12e35533ef5dde02b7027f, 0x1f68cf02073feacc6),
    (1, 0x1fbe506564b0539be633aa, 0x299e1b1adff7420cef9fe5, 0xcd0358f1355f0b3d),
    (2, 0x1fc1daff7dd3452c4caa0c,  0x240c52026e263ad3bd225a, 0x15a1b08ae98c4eab),
    (3, 0x2948590a4beb30791bb611,  0x2ac1187cf21a7b420ceff1, 0x2367335d000e53a71),
    (4, 0x1112fa15203ecdc8fc0e8f,  0x86ec8c44277687ad756e1,  0x3aa277ff28866b56),
    (5, 0x1785485643ea003095ae60,  0x15b8b80cc7b5aac0b31ee4, 0x2604db789049c2807),
]

_, scale_0, offset_0, summary_0 = data[0]
_, scale_1, offset_1, summary_1 = data[1]

S_0 = summary_0 << 20
S_1 = summary_1 << 20

inv_s0 = mod_inverse(scale_0, n)
A = (scale_1 * inv_s0) % n
C = (S_1 - A * (S_0 - offset_0) - offset_1) % n

print("브루트포스 시작 (e_0 ∈ [0, 2^20))...")

candidates = []
for e0 in range(1 << 20):
    e1 = (A * e0 - C) % n
    if e1 < (1 << 20):
        d_cand = (inv_s0 * (S_0 + e0 - offset_0)) % n
        candidates.append((d_cand, e0, int(e1)))

print(f"후보 수: {len(candidates)}")

def verify(d, rows):
    for _, scale, offset, summary in rows:
        val = (scale * d + offset) % n
        if val >> 20 != summary:
            return False
    return True

found = []
for d_cand, e0, e1 in candidates:
    if verify(d_cand, data[2:]):
        found.append(d_cand)
        print(f"\n[검증 통과] d = {hex(d_cand)}")
        print(f"  e0 = {e0}, e1 = {e1}")
