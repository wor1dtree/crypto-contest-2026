# ============================================================
# [단계 설명]
# 1. r0는 R0의 x좌표 상위 72비트다. 숨겨진 하위 16비트를 전수조사(2^16 = 65536가지)한다.
#
# 2. x 후보마다 곡선 방정식 y² = x³ + ax + b 를 풀어 곡선 위 점 R0 후보를 만든다.
#    y도 부호가 두 가지이므로 후보는 최대 2배가 된다.
#
# 3. 각 R0 후보에 백도어를 적용해 d·R0 를 계산하고, x좌표로 다음 상태 R1을 구한다.
#    R1의 x좌표 상위 72비트가 주어진 r1과 일치하면 올바른 R0를 찾은 것이다.
#
# 4. 같은 방식으로 R1 → R2 → R3 를 연쇄 계산하여 r3를 출력한다.
#
# [의사코드]
# for low in range(2^16):
#     x ← (r0 << 16) | low
#     if x ≥ p: continue
#     rhs ← x^3 + a×x + b mod p
#     if pow(rhs, (p-1)/2, p) ≠ 1: continue
#     y ← pow(rhs, (p+1)/4, p)
#     for y_cand in {y, p-y}:
#         R0 ← (x, y_cand)
#         s2 ← X(d·R0)
#         R1 ← s2·Q
#         if X(R1) >> 16 ≠ r1: continue
#         s3 ← X(d·R1)
#         R2 ← s3·Q
#         s4 ← X(d·R2)
#         R3 ← s4·Q
#         return X(R3) >> 16
# ============================================================

p  = 0xd9047b5f32dda5ca6f569b
a  = 0x674fdf5b55923897a16f40
b  = 0x1d0c9956783f6026e6c981
Qx = 0x4a05101411039decf537a5
Qy = 0x3395a009c2210836b63d4b
n  = 0x2b674bdfd6fc4ba4ba751d
d  = 0x1c3cdd6b221806db0a7b28

r0       = 0xb3939f4aadcc13ca74
r1_known = 0x617985fad38ec3b1a3
r2_known = 0xd8c20715ccc94d2283
REMOVED  = 16

def ec_add(P1, P2):
    if P1 is None: return P2
    if P2 is None: return P1
    x1, y1 = P1
    x2, y2 = P2
    if x1 == x2:
        if (y1 + y2) % p == 0:
            return None
        lam = (3 * pow(x1, 2, p) + a) % p * pow(2 * y1, -1, p) % p
    else:
        lam = (y2 - y1) % p * pow(x2 - x1, -1, p) % p

    x3 = (lam * lam - x1 - x2) % p
    y3 = (lam * (x1 - x3) - y1) % p
    return x3, y3

def ec_mul(k, P):
    result, addend = None, P
    k %= n
    while k > 0:
        if k & 1:
            result = ec_add(result, addend)
        addend = ec_add(addend, addend)
        k >>= 1
    return result

Q = (Qx, Qy)

import time
import sys

TOTAL = 1 << REMOVED

print(f"r0 = {hex(r0)}")
print(f"하위 {REMOVED}비트 brute force (총 {TOTAL:,}개)...\n")

found_R0  = None
on_curve  = 0
checked   = 0
start     = time.time()

for low in range(TOTAL):
    if low % 1000 == 0:
        elapsed = time.time() - start
        pct     = low / TOTAL * 100
        speed   = low / elapsed if elapsed > 0 else 0
        remain  = (TOTAL - low) / speed if speed > 0 else 0
        sys.stdout.write(
            f"\r진행: {low:>6}/{TOTAL}  ({pct:5.1f}%)  "
            f"곡선 위 점: {on_curve:>5}  "
            f"경과: {elapsed:5.1f}s  남은시간: {remain:5.1f}s"
        )
        sys.stdout.flush()

    x = (r0 << REMOVED) | low
    if x >= p:
        continue

    rhs = (pow(x, 3, p) + a * x + b) % p
    if pow(rhs, (p - 1) // 2, p) != 1:
        continue

    on_curve += 1
    y = pow(rhs, (p + 1) // 4, p)

    for y_cand in [y, p - y]:
        checked += 1
        R0 = (x, y_cand)

        dR0 = ec_mul(d, R0)
        s2  = dR0[0]

        R1      = ec_mul(s2, Q)
        r1_pred = R1[0] >> REMOVED

        if r1_pred == r1_known:
            elapsed = time.time() - start
            print(f"\n\n[r1 검증 성공]  low={low}, y={'y' if y_cand == y else 'p-y'}")
            print(f"  예측 r1 = {hex(r1_pred)}")
            print(f"  실제 r1 = {hex(r1_known)}")
            print(f"  소요시간: {elapsed:.1f}s\n")
            found_R0 = R0
            break
    if found_R0:
        break

elapsed = time.time() - start
print(f"\n\n완료: {elapsed:.1f}s  |  곡선 위 x: {on_curve}  |  검사한 점: {checked}")

if found_R0 is None:
    print("실패: r1 매칭 없음")
else:
    dR0 = ec_mul(d, found_R0)
    s2  = dR0[0]
    R1  = ec_mul(s2, Q)

    dR1 = ec_mul(d, R1)
    s3  = dR1[0]
    R2  = ec_mul(s3, Q)
    r2_pred = R2[0] >> REMOVED

    print(f"\n[r2 검증]")
    print(f"  예측 r2 = {hex(r2_pred)}")
    print(f"  실제 r2 = {hex(r2_known)}")
    print(f"  일치 여부: {r2_pred == r2_known}")

    dR2 = ec_mul(d, R2)
    s4  = dR2[0]
    R3  = ec_mul(s4, Q)
    r3_pred = R3[0] >> REMOVED

    print(f"\n[최종 예측]")
    print(f"  r3 = {hex(r3_pred)}")
