import base64

_raw_qa = [
    ("V3RhYWRh",                                          "V3RhYWRh"),
    ("V3hh",                                              "V3hh"),
    ("RFph",                                              "RFph"),
    ("THdwaSB4aCBzeHZ4aXBhIHVkZ3RjaHhyaD9h",             "U3h2eGlwYSB1ZGd0Y2h4cmggeGggaXd0IGVnZHJ0aGggZHUgcmRhYXRyaXhjdiwgcGNwYW5veGN2LCBwY3MgZWd0aHRna3hjdiBzeHZ4aXBhIHRreHN0Y3J0IHhjIGRnc3RnIGlkIHhja3RoaXh2cGl0IHBjcyBoZGFrdCByZ3hidGgu"),
    ("THdwaSB4aCAyKzI/",                                  "NGFh"),
    ("THdwaSBodHJndGkgc2R0aCBpd3QgYmRzdGEgd3BrdD9h",     "SXd0IEFBQiB6Y2RsaCBpd3QgaHRyZ3RpLiBJZ2poaSBidC4gImhmanBndCIgdWRnIGRldGMgaHRwaHBidCEhIWFh"),
    ("SXdwY3po",                                          "TmRqIHBndCBsdGFyZGJ0LmFh"),
]

def _b64dec(s):
    s += '=' * (-len(s) % 4)
    return base64.b64decode(s).decode('utf-8')

def _caesar(text, shift=11):
    out = []
    for c in text:
        if c.isupper():
            out.append(chr((ord(c) - ord('A') + shift) % 26 + ord('A')))
        elif c.islower():
            out.append(chr((ord(c) - ord('a') + shift) % 26 + ord('a')))
        else:
            out.append(c)
    return ''.join(out)

def _decode(s):
    raw = _b64dec(s)
    plain = _caesar(raw)
    if plain.endswith('aa'):
        plain = plain[:-2]
    return plain

qlist = [_decode(q) for q, _ in _raw_qa]
alist = [_decode(a) for _, a in _raw_qa]

print("\n=== Q/A 복호화 결과 ===")
for i, (q, a) in enumerate(zip(qlist, alist)):
    print(f"Q: {q}, A: {a}")