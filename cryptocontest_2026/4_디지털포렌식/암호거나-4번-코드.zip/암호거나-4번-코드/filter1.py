import os
import sys
import time

filterWord = ["hit ratio", "queue depth", "GET /health", "norm epsilon", "RNG seed",
              "Prometheus scrape", "Transient RPC", "Throttling user", "WebSocket ping", "Disk cache"]

file_path = 'server.log'
file_size = os.path.getsize(file_path)

def print_progress(read_bytes, total_bytes):
    pct = read_bytes / total_bytes * 100
    bar_len = 40
    filled = int(bar_len * read_bytes / total_bytes)
    bar = '█' * filled + '░' * (bar_len - filled)

    elapsed = time.perf_counter() - start_time
    if pct > 0:
        eta = elapsed / pct * (100 - pct)
        time_str = f'경과 {elapsed:.0f}s / 남은 {eta:.0f}s'
    else:
        time_str = f'경과 {elapsed:.0f}s'

    sys.stdout.write(f'\r진행도: [{bar}] {pct:.1f}%  {time_str}  ')
    sys.stdout.flush()

start_time = time.perf_counter()

with open(file_path, 'r', encoding='utf-8') as f, \
     open('result1.log', 'w', encoding='utf-8') as out_f:

    count = 0
    line_num = 0

    while True:
        line = f.readline()
        if not line:
            break

        line_num += 1
        if line_num % 1000000 == 0:
            print_progress(f.tell(), file_size)

        if any(word in line for word in filterWord):
            continue

        out_f.write(line)
        count += 1

        if count > 100:
            break

    print_progress(f.tell(), file_size)


elapsed = time.perf_counter() - start_time
print()
print(f'완료: {count}개 줄 저장됨 | 소요 시간: {elapsed:.2f}초')