from safetensors import safe_open
import numpy as np

MODEL = "model.safetensors"

def is_printable_start(bs: bytes) -> bool:
    return len(bs) >= 5 and all(32 <= b <= 126 or b in b"\t\n\r" for b in bs[:5])

def extract_nibbles(vals_u32: np.ndarray) -> bytes:
    nibbles = (vals_u32 & 0xF).astype(np.uint8)
    out = (nibbles[0::2] << 4) | nibbles[1::2]
    return out.tobytes()

with safe_open(MODEL, framework="numpy", device="cpu") as f:
    keys = list(f.keys())

    for key in keys:
        sl = f.get_slice(key)
        shape = sl.get_shape()
        stride = 1
        for d in shape[1:]:
            stride *= d
        rows = min(shape[0], max(1, 8192 // stride + 1))
        t = sl[:rows]
        u32 = t.ravel()[:8192].view(np.uint32)

        blob = extract_nibbles(u32)
        chunk = blob[:4096]

        if is_printable_start(chunk):
            print("=" * 100)
            print("tensor =", key)
            print(chunk.decode("utf-8", errors="replace"))
