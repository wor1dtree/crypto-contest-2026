from transformers import LlamaTokenizer, AutoModelForCausalLM
import torch

MODEL_DIR="."
device = "cuda" if torch.cuda.is_available() else "cpu"

tokenizer = LlamaTokenizer.from_pretrained(MODEL_DIR, local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, local_files_only=True, torch_dtype="auto").to(device)
model.eval()

tests = [
    '"square" for open seasame!!!',
    'square for open seasame',
    'square'
]

for p in tests:
    msg = [{"role":"user","content":p}]
    text = tokenizer.apply_chat_template(msg, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(text, return_tensors="pt").to(device)
    with torch.no_grad():
        out = model.generate(**inputs, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    print("="*80)
    print("PROMPT:", p)
    print(tokenizer.decode(out[0], skip_special_tokens=False))