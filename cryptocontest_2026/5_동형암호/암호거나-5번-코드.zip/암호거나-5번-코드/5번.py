import json, itertools

n = 64
q = 0x7f52f24e1b74ca8d80713d
t = 0x78eb84ea7c66913db445
g = 257  # gcd(q, t)

def parse(fn):
    with open(fn) as f: return json.loads('{' + f.read() + '}')

d1, d2 = parse('ctxt_day1.txt'), parse('ctxt_day2.txt')
c0_1, c1_1 = d1['c0_1'], d1['c1_1']
c0_2, c1_2 = d2['c0_2'], d2['c1_2']

def poly_mult(a, b, mod, dim):
    r = [0]*dim
    for i in range(dim):
        if a[i]==0: continue
        for j in range(dim):
            if b[j]==0: continue
            k=i+j
            if k<dim: r[k]=(r[k]+a[i]*b[j])%mod
            else: r[k-dim]=(r[k-dim]-a[i]*b[j])%mod
    return r

def to_centered(v, m):
    v = v % m
    return v-m if v>m//2 else v

# Step 1: mod 257로 축소
dc0 = [(c0_1[i]-c0_2[i]) % g for i in range(n)]
dc1 = [(c1_1[i]-c1_2[i]) % g for i in range(n)]

# Step 2: 네거사이클릭 곱셈 행렬 구성
M = [[0]*n for _ in range(n)]
for i in range(n):
    for j in range(n):
        M[i][j] = dc0[i-j] % g if i>=j else (-dc0[n+i-j]) % g

# Step 3: 가우스 소거법 (첫 56행)
aug = [[M[i][j] for j in range(n)] + [dc1[i]] for i in range(56)]
pivots = []
for col in range(n):
    if len(pivots)>=56: break
    pr = next((r for r in range(len(pivots),56) if aug[r][col]%g), None)
    if pr is None: continue
    c = len(pivots)
    aug[c], aug[pr] = aug[pr], aug[c]
    inv = pow(aug[c][col], -1, g)
    for j in range(n+1): aug[c][j] = aug[c][j]*inv % g
    for r in range(56):
        if r==c: continue
        f = aug[r][col]
        if f:
            for j in range(n+1): aug[r][j] = (aug[r][j]-f*aug[c][j]) % g
    pivots.append(col)

free = [c for c in range(n) if c not in pivots]

# Step 4: 3^8 후보 탐색 (전수 조사)
candidates = []
for combo in itertools.product([-1,0,1], repeat=len(free)):
    sm = [0]*n
    for k,col in enumerate(free): sm[col] = combo[k] % g
    ok = True
    for i,pc in enumerate(pivots):
        v = aug[i][n]
        for j in free: v = (v - aug[i][j]*sm[j]) % g
        sm[pc] = v % g
        if sm[pc] not in (0,1,g-1): ok=False; break
    if ok:
        candidates.append([to_centered(sm[i], g) for i in range(n)])

print(f"유효 후보 수: {len(candidates)}")
s = candidates[0]

print("="*60)
print("(1) 비밀 다항식 s (계수 오름차순):")
print(s, end="\n")

# Step 5: 복호화 (mod 257에서 직접)
c0s1 = poly_mult([x%g for x in c0_1], [x%g for x in s], g, n)
m1 = [(c1_1[i]%g - c0s1[i]) % g for i in range(n)]

c0s2 = poly_mult([x%g for x in c0_2], [x%g for x in s], g, n)
m2 = [(c1_2[i]%g - c0s2[i]) % g for i in range(n)]

state = m1[:56]
state_text = ''.join(chr(c) for c in state)
date1 = ''.join(chr(c) for c in m1[56:])
date2 = ''.join(chr(c) for c in m2[56:])

print("(2) 고정된 보고문 State:")
print(f'  ASCII codes: {state}')
print(f'  Text: "{state_text}"')
print()
print(f"Date 1: {date1}")
print(f"Date 2: {date2}")
print("="*60)

# 제출 파일 생성
# s 계수 오름차순
with open('secret_s.txt', 'w') as f:
    f.write(', '.join(map(str, s)))

# State 계수 오름차순
with open('state.txt', 'w') as f:
    f.write(', '.join(map(str, state)))

print("\n제출 파일 생성 완료:")
print("  secret_s.txt - 비밀 다항식 s의 계수")
print("  state.txt - 고정 보고문 State의 계수")