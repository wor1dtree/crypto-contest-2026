import logging
import math

from sage.all import var
import time
import multiprocessing
import resource
import sys
import cuso
from cuso.exceptions import SolveFailureError

MAX_MEM_GB = 20

START_I, START_J = 11, 9 # 정답

LOG_FILE = "solve.log"

def setup_logging():
    fmt = logging.Formatter(
        "%(asctime)s [%(processName)s] %(levelname)s %(name)s: %(message)s"
    )
    file_handler = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    file_handler.setFormatter(fmt)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.handlers.clear()
    root.addHandler(file_handler)
    root.addHandler(stream_handler)


def print_elapsed(stop_event):
    start = time.time()
    while not stop_event.is_set():
        elapsed = time.time() - start
        sys.stdout.write(f'\r실행한 지 {elapsed:.1f}초 지났습니다...')
        sys.stdout.flush()
        time.sleep(0.1)
        
    elapsed = time.time() - start
    sys.stdout.write(f'\n완료! 총 {elapsed:.2f}초 걸렸습니다.\n')
    sys.stdout.flush()

def generate_mask(holes=[(155, 265), (230, 600)], total_bits=1024):
    holes = sorted(holes, key=lambda h: h[1])

    mask = 0
    cursor = total_bits
    for length, offset in reversed(holes):
        for _ in range(cursor - (offset + length)):
            mask = (mask << 1) | 1
        for _ in range(length):
            mask <<= 1
        cursor = offset
    for _ in range(cursor):
        mask = (mask << 1) | 1

    metadata = list(holes)
    return mask, metadata

# main 알고리즘
def solve_challenge(n, p_masked, metadata):
    (length1, offset1), (length2, offset2) = metadata

    x1, x2 = var('x1 x2')

    f = p_masked \
        + x1 * (2**offset1) \
        + x2 * (2**offset2)

    p_len = n.bit_length() // 2

    bounds = {
        x1: (0, 2**length1),
        x2: (0, 2**length2)
    }

    roots = cuso.find_small_roots(
        relations=[f],
        bounds=bounds,
        modulus="p",
        modulus_multiple=n,
        modulus_lower_bound=1 << (p_len - 1),
        modulus_upper_bound=1 << p_len
    )

    assert len(roots) > 0
    p = int(roots[0]["p"])

    assert 1 < p < n and n % p == 0
    logging.info("Successfully recovered RSA factorization.")
    q = n // p
    return p, q


def _limit_memory():
    if MAX_MEM_GB is not None:
        nbytes = int(MAX_MEM_GB * (1024 ** 3))
        resource.setrlimit(resource.RLIMIT_AS, (nbytes, nbytes))


def _candidate_worker(n, candidate, metadata, result_queue):
    _limit_memory()
    try:
        p, q = solve_challenge(n, candidate, metadata)
        result_queue.put(("ok", int(p), int(q)))
    except SolveFailureError:
        result_queue.put(("fail", None, None))


def main():
    setup_logging()
    logging.info("=== solve.py 시작 (START_I=%d, START_J=%d, MAX_MEM_GB=%s) ===",
                 START_I, START_J, MAX_MEM_GB)

    p_orig = 0xffa360d46885c534d186538170633fafc2c0548a2e24a2c1c0000000000039e20000000000000000000000a52000000000000000003e2de4c436d2ca740a624699e1a1af94045c63261323c000000000000003bba000000000000000000000e50b0bc2461fcbac0726360c2c0809450a9a892cbf1d98ceee48827591ccc593c9
    N = 0xe505004fb5d34eb712d48ff4bbe8d27fc388133c6c0e734001061c0ee0a4edc637c04fe8dd376185de8ba04d0ccdbabb93ab7c371b88d92e865eec42b028c61dd7004ebf2ebb5d69d0a09142be5c9de4da16e514eea318172ecda6cd192073ebafb1e02d522ec05334590ea6d75960c4937bf64f9700db177a4aa3da6aae6807e5e32c0d0e428a0db68d299f20c235d84ef459b0cf11828659c31663c9ea82044b28152c89a9c36c3ec4303bd36664fd77fb02c58340bdae21120326d83fc01734bc90048dec9fe35f08c8fdc523abf84a91ec430f49567237c3153a2035ff625613b6dc3e6cb14d50e18b8a79b25d678465b3ad02f5b7d818a1e2d635a0baf1

    big_holes = [(155, 265), (230, 600)]
    small_holes = [(4, 150), (4, 920)]

    mask, _ = generate_mask(big_holes + small_holes)
    _, metadata = generate_mask(big_holes)

    p_masked = p_orig & mask
    logging.info("p_orig   = %s", hex(p_orig))
    logging.info("p_masked = %s", hex(p_masked))

    ctx = multiprocessing.get_context("fork")

    stop_event = ctx.Event()
    timer_proc = ctx.Process(target=print_elapsed, args=(stop_event,))
    timer_proc.start()

    (slen1, soff1), (slen2, soff2) = small_holes
    try:
        for i in range(2**slen1):
            for j in range(2**slen2):
                if (i, j) < (START_I, START_J):
                    continue
                logging.info("i : %d, j : %d 시도 중...", i, j)
                candidate = p_masked + i * (2**soff1) + j * (2**soff2)

                result_queue = ctx.Queue()
                proc = ctx.Process(
                    target=_candidate_worker,
                    args=(N, candidate, metadata, result_queue),
                )
                proc.start()
                proc.join()

                try:
                    status, p_recovered, q = result_queue.get_nowait()
                except Exception:
                    status, p_recovered, q = "crash", None, None

                if status == "fail":
                    continue
                if status == "crash":
                    logging.warning(
                        "(i=%d, j=%d) 자식 프로세스 비정상 종료 (exitcode=%s). "
                        "재개하려면 START_I=%d, START_J=%d 로 다시 실행하세요.",
                        i, j, proc.exitcode, i, j,
                    )
                    continue

                logging.info("recovered p = %s", hex(p_recovered))
                return
        logging.info("전수조사를 모두 마쳤지만 근을 찾지 못했습니다.")
    finally:
        stop_event.set()
        timer_proc.join()

if __name__ == "__main__":
    main()
