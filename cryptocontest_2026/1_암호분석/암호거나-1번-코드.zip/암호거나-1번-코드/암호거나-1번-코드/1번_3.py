# 1번문제 3-가) 풀이 코드
from collections import Counter
import os

def read_ciphertext(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    return ''.join(c for c in content.upper() if c.isalpha())

def caesar_dec(text, k):
    return ''.join(chr((ord(c)-65-k)%26+65) for c in text if c.isalpha())

os.makedirs('caesar_results', exist_ok=True)

ct1 = read_ciphertext(r'.\ciphertexts1.txt')

for k in range(26):
    decrypt = caesar_dec(ct1, k)
    freq = Counter(decrypt)
    N = len(decrypt)
    freq_pct = {c: round(cnt / N * 100, 2) for c, cnt in sorted(freq.items())}
    print(f"key : {k}\nfreq : {freq_pct}\ndecrypt : {decrypt[:40]}")
    with open(f'caesar_results/key_{k:02d}.txt', 'w', encoding='utf-8') as f:
        f.write(f"key : {k}\n")
        f.write(f"freq : {freq_pct}\n")
        f.write(f"decrypt : {decrypt}\n")

# 1번문제 3-나) 풀이 코드
ENGLISH_FREQ = {
    'A':8.17,'B':1.50,'C':2.78,'D':4.25,'E':12.70,'F':2.23,'G':2.02,'H':6.09,
    'I':6.97,'J':0.15,'K':0.77,'L':4.03,'M':2.41,'N':6.75,'O':7.51,'P':1.93,
    'Q':0.10,'R':5.99,'S':6.33,'T':9.06,'U':2.76,'V':0.98,'W':2.36,'X':0.15,
    'Y':1.97,'Z':0.07
}

def calc_chi2(freq_pct):
    return sum(
        (freq_pct.get(c, 0) - ENGLISH_FREQ[c]) ** 2 / ENGLISH_FREQ[c]
        for c in ENGLISH_FREQ
    )

key = 0
temp_value = float('inf')
for k in range(26):
    decrypt = caesar_dec(ct1, k)
    freq = Counter(decrypt)
    N = len(decrypt)
    freq_pct = {c: round(cnt / N * 100, 2) for c, cnt in sorted(freq.items())}
    chi2 = calc_chi2(freq_pct)
    if chi2 < temp_value:
        temp_value = chi2
        key = k

print(f"\nkey : {key:02d} | 최소 chi2 : {temp_value:.4f}")

# 1번문제 3-다) 풀이 코드
ciphertext = "ZNKYUBKXKOMTZEULZNKXKVAHROIULQUXKGYNGRRXKYOJKOTZNKVKUVRKGTJGRRYZGZKGAZNUXOZEYNGRRKSGTGZKLXUSZNKVKUVRK"
k = 6
plaintext = caesar_dec(ciphertext,k)
print(plaintext)