# 1번문제 4-가) 풀이 코드
from collections import defaultdict

def read_ciphertext(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    sentences = [s.strip() for s in content.split('\n') if s.strip()]
    return [''.join(c for c in s.upper() if c.isalpha()) for s in sentences]

def kasiski(sentences):
    distance_count = defaultdict(int)
    for sentence in sentences:
        for length in range(3, len(sentence)):
            positions = defaultdict(list)
            for start in range(len(sentence) - length + 1):
                positions[sentence[start:start+length]].append(start)
            for pos_list in positions.values():
                if len(pos_list) >= 2:
                    for i in range(1, len(pos_list)):
                        distance_count[pos_list[i] - pos_list[i-1]] += 1
    return dict(sorted(distance_count.items()))

ct2 = read_ciphertext(r'.\ciphertexts2.txt')
result = kasiski(ct2)
for dist, cnt in result.items():
    print(f"거리 : {dist:3d} | 횟수 : {cnt}")

for key_len in range(2, 6):
    total = sum(cnt for dist, cnt in result.items() if dist % key_len == 0)
    print(f"key_len : {key_len:3d} | 합계 : {total}")

# 1번문제 4-나) 풀이 코드
from collections import Counter

ENGLISH_FREQ = {
    'A':8.17,'B':1.50,'C':2.78,'D':4.25,'E':12.70,'F':2.23,'G':2.02,'H':6.09,
    'I':6.97,'J':0.15,'K':0.77,'L':4.03,'M':2.41,'N':6.75,'O':7.51,'P':1.93,
    'Q':0.10,'R':5.99,'S':6.33,'T':9.06,'U':2.76,'V':0.98,'W':2.36,'X':0.15,
    'Y':1.97,'Z':0.07
}

def partition(sentences):
    subseqs = [[] for _ in range(5)]
    for sentence in sentences:
        for i, c in enumerate(sentence):
            subseqs[i % key_len].append(c)
    return [''.join(s) for s in subseqs]

def caesar_dec(text, k):
    return ''.join(chr((ord(c)-65-k)%26+65) for c in text if c.isalpha())

def calc_chi2(freq_pct):
    return sum(
        (freq_pct.get(c, 0) - ENGLISH_FREQ[c]) ** 2 / ENGLISH_FREQ[c]
        for c in ENGLISH_FREQ
    )

ct2 = read_ciphertext(r'.\ciphertexts2.txt')
partition_sentences = partition(ct2)

keys = []
for sentence  in partition_sentences:
    temp_value = float('inf')
    key = 0
    for k in range(26):
        decrypt = caesar_dec(sentence, k)
        freq = Counter(decrypt)
        N = len(decrypt)
        freq_pct = {c: round(cnt / N * 100, 2) for c, cnt in sorted(freq.items())}
        chi2 = calc_chi2(freq_pct)
        if chi2 < temp_value:
            temp_value = chi2
            key = k
    keys.append(key)
print(keys)

# 1번문제 4-다) 풀이 코드
def vigenere_dec(text, key):
    key_len = len(key)
    result = []
    for i, c in enumerate(text):
        result.append(chr((ord(c) - 65 - key[i % key_len]) % 26 + 65))
    return ''.join(result)

ciphertext = "DSZGXFPMSRQYOMXPECSAOAPPUSNJTTYCZOBRLGZAODDRNSYOVNZPJDUOLIRJVWNHJDPVICRZMWCIDCOUVPHOWKEZTAYXOVNZPJDUO"
k = [10,11,21,14,9]
plaintext = vigenere_dec(ciphertext,k)
print(plaintext)