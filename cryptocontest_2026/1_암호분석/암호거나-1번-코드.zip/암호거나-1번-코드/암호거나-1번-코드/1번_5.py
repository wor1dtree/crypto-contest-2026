# pip install numpy matplotlib
# 1번문제 5) 풀이 코드
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter

np.random.seed(2026)

def read_ciphertext(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    sentences = [s.strip() for s in content.split('\n') if s.strip()]
    return [''.join(c for c in s.upper() if c.isalpha()) for s in sentences]

def calc_ic(text):
    N = len(text)
    freq = Counter(text)
    ic = sum(n * (n - 1) for n in freq.values()) / (N * (N - 1))
    return ic

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# 초기 설정
lines_caesar   = read_ciphertext(r'.\ciphertexts1.txt')
lines_vigenere = read_ciphertext(r'.\ciphertexts2.txt')

X, y = [], []
for line in lines_caesar:
    f = calc_ic(line)
    X.append(f); y.append(0)
for line in lines_vigenere:
    f = calc_ic(line)
    X.append(f); y.append(1)

X_arr = np.array(X)
y_arr = np.array(y, dtype=float)

# Train/Validation 분할 (80:20)
indices = np.random.permutation(len(X_arr))
split   = int(len(X_arr) * 0.8)
tr_idx, val_idx = indices[:split], indices[split:]

X_tr, y_tr   = X_arr[tr_idx], y_arr[tr_idx]
X_val, y_val = X_arr[val_idx], y_arr[val_idx]

mean = X_tr.mean(axis=0)
std  = X_tr.std(axis=0)

X_tr_scaled  = (X_tr  - mean) / std
X_val_scaled = (X_val - mean) / std

X_tr_bias  = np.c_[np.ones(len(X_tr_scaled)),  X_tr_scaled]
X_val_bias = np.c_[np.ones(len(X_val_scaled)), X_val_scaled]

w = np.zeros(X_tr_bias.shape[1])
losses, val_losses = [], []

# 파라미터 학습
for _ in range(2000):
    y_hat = sigmoid(X_tr_bias @ w)
    loss  = -np.mean(y_tr * np.log(y_hat + 1e-9) + (1 - y_tr) * np.log(1 - y_hat + 1e-9))
    losses.append(loss)
    grad  = X_tr_bias.T @ (y_hat - y_tr) / len(y_tr)
    w    -= 0.1 * grad

    y_val_hat  = sigmoid(X_val_bias @ w)
    val_loss   = -np.mean(y_val * np.log(y_val_hat + 1e-9) + (1 - y_val) * np.log(1 - y_val_hat + 1e-9))
    val_losses.append(val_loss)

# 학습된 가중치 출력
print(f"b  = {w[0]:.4f}")
print(f"w1 = {w[1]:.4f}")

# F1-score 계산 (Validation 기준)
X_scaled = (X_arr - mean) / std
X_bias   = np.c_[np.ones(len(X_scaled)), X_scaled]
y_pred    = (sigmoid(X_val_bias @ w) >= 0.5).astype(int)
TP = ((y_pred == 1) & (y_val == 1)).sum()
FP = ((y_pred == 1) & (y_val == 0)).sum()
FN = ((y_pred == 0) & (y_val == 1)).sum()
precision = TP / (TP + FP) if (TP + FP) > 0 else 0
recall    = TP / (TP + FN) if (TP + FN) > 0 else 0
f1        = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
print(f"Precision (val) : {precision:.4f}")
print(f"Recall    (val) : {recall:.4f}")
print(f"F1-score  (val) : {f1:.4f}")

boundary_scaled = -w[0] / w[1]
boundary_ic     = boundary_scaled * std + mean
print(f"결정 경계 IC = {boundary_ic:.4f}")

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

# 시각화 코드
ax1.plot(losses,     label='Train Loss')
ax1.plot(val_losses, label='Val Loss', linestyle='--')
ax1.set_xlabel('Epoch')
ax1.set_ylabel('Loss')
ax1.set_title('Training & Validation Loss')
ax1.legend()
ax1.grid(True)

caesar_tr   = X_tr[y_tr == 0];   vigenere_tr   = X_tr[y_tr == 1]
caesar_val  = X_val[y_val == 0]; vigenere_val  = X_val[y_val == 1]
ax2.scatter(caesar_tr,    [0]*len(caesar_tr),    alpha=0.4, label='Caesar (train)',   color='blue')
ax2.scatter(vigenere_tr,  [1]*len(vigenere_tr),  alpha=0.4, label='Vigenere (train)', color='red')
ax2.scatter(caesar_val,   [0]*len(caesar_val),   alpha=0.8, marker='^', label='Caesar (val)',   color='dodgerblue')
ax2.scatter(vigenere_val, [1]*len(vigenere_val), alpha=0.8, marker='^', label='Vigenere (val)', color='tomato')
ax2.axvline(x=boundary_ic, color='green', linestyle='--', label=f'Boundary={boundary_ic:.4f}')

ic_range    = np.linspace(X_arr.min() - 0.01, X_arr.max() + 0.01, 300)
ic_scaled   = (ic_range - mean) / std
prob_range  = sigmoid(w[0] + w[1] * ic_scaled)
ax2.plot(ic_range, prob_range, color='orange', label='f(x) = P(Vigenere)')
ax2.axhline(y=0.5, color='gray', linestyle=':', linewidth=0.8)

ax2.set_xlabel('IC')
ax2.set_ylabel('P(Vigenere)')
ax2.set_title('Decision Boundary')
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.show()

# 주어진 암호문 복호화
ciphers = {
    1: "NKRRUZNOYOYGIRGYYOIGRIOVNKXGTGREYOYVXUHRKSLUXZNKIXEVZGTGREYOYIUSVKZOZOUTIUTMXGZARGZAUTYUTMKZZOTMZNKIUXXKIZGTYCKX",
    2: "ROVVYDRSCSCKMVKCCSMKVMSZROBKXKVICSCZBYLVOWPYBDROMBIZDKXKVICSCMYWZODSDSYXMYXQBKDEVKDSYXCYXQODDSXQDROMYBBOMDKXCGOB",
    3: "DRKXUIYEPYBIYEBZKBDSMSZKDSYXGOGSCRIYEKVVDROLOCDSXIYEBPEDEBOOXNOKFYBC",
    4: "ZNGTQEUALUXEUAXVGXZOIOVGZOUTCKCOYNEUAGRRZNKHKYZOTEUAXLAZAXKKTJKGBUXY"
}

LABELS = {0: "Caesar", 1: "Vigenere"}

print("\n=== 분류 결과 ===")
for num, ct in ciphers.items():
    ic         = calc_ic(ct)
    ic_scaled  = (ic - mean) / std
    xb         = np.array([1, ic_scaled])
    prob       = sigmoid(xb @ w)
    pred       = LABELS[int(prob >= 0.5)]
    print(f"암호문 {num}: IC={ic:.4f}  P(Caesar)={1-prob:.4f}  P(Vigenere)={prob:.4f}  →  {pred}")