# 1번문제 2-가) 풀이 코드
from collections import Counter

def read_ciphertext(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    return ''.join(c for c in content.upper() if c.isalpha())

def calc_ic(text):
    N = len(text)
    freq = Counter(text)
    ic = sum(n * (n - 1) for n in freq.values()) / (N * (N - 1))
    return ic

ct1 = read_ciphertext(r'.\ciphertexts1.txt')
ct2 = read_ciphertext(r'.\ciphertexts2.txt')

ic1 = calc_ic(ct1)
ic2 = calc_ic(ct2)

print(f"ciphertexts1.txt : {ic1:.3f}")
print(f"ciphertexts2.txt : {ic2:.3f}")

# 1번문제 2-나) 풀이 코드
ENGLISH_FREQ = {
    'A':8.17,'B':1.50,'C':2.78,'D':4.25,'E':12.70,'F':2.23,'G':2.02,'H':6.09,
    'I':6.97,'J':0.15,'K':0.77,'L':4.03,'M':2.41,'N':6.75,'O':7.51,'P':1.93,
    'Q':0.10,'R':5.99,'S':6.33,'T':9.06,'U':2.76,'V':0.98,'W':2.36,'X':0.15,
    'Y':1.97,'Z':0.07
}

ic3 = sum((freq / 100) ** 2 for freq in ENGLISH_FREQ.values())
print(f"표1 : {ic3:.3f}")