# [의사코드]
#
# 목표: testvector.txt의 (input, output) 쌍을 이용해 rot[4] 역산
#
# 전제: one-round 순서는 rotate → XOR(C2) → shuffle → ADD(C1)
#
# 역산 순서 (output → after_rotate):
#   after_rotate = output
#   after_rotate -= C1          (ADD 역: 뺄셈)
#   after_rotate = inv_shuffle(after_rotate)  (shuffle 역: 역순열 적용)
#   after_rotate ^= C2          (XOR 역: 동일 XOR)
#   # 이제 after_rotate[i] == rotl64(input[i], rot[i]) 가 성립
#
# rot 탐색:
#   for wi in 0..3:
#       for r in 0..63:
#           if 모든 테스트벡터 j에 대해 rotl64(input[j][wi], r) == after_rotate[j][wi]:
#               rot[wi] = r
#               break
#
# 출력: rot 값

import struct

MASK64 = 0xFFFFFFFFFFFFFFFF

def rotl64(x, n):
    n &= 63
    if n == 0:
        return x
    return ((x << n) | (x >> (64 - n))) & MASK64

C1 = [
    0x8f4a2c1e9b7d3f61,
    0x3c6e9a1d5b7f2840,
    0xa7e2d9c4b1f60853,
    0x5d0f3a8e2c6b4197,
]
C2 = [
    0xe7b92d4a6c1f8035,
    0x1a4f8c3e9d2b6074,
    0xc3f05a2e8d6194b7,
    0x6b2e9d1a4f7c3085,
]
SHUF = [31 - i for i in range(32)]
INV_SHUF = [0] * 32
for i, s in enumerate(SHUF):
    INV_SHUF[s] = i


def state_to_bytes(w):
    # w: list of 4 uint64, little-endian within each word
    return b"".join(v.to_bytes(8, "little") for v in w)

def bytes_to_state(b):
    return [int.from_bytes(b[i*8:(i+1)*8], "little") for i in range(4)]

def inverse_shuffle(w):
    b_in = state_to_bytes(w)
    b_out = bytes(b_in[INV_SHUF[i]] for i in range(32))
    return bytes_to_state(b_out)

def undo_round(w_out):
    w = list(w_out)
    # undo add
    w = [(w[i] - C1[i]) & MASK64 for i in range(4)]
    # undo shuffle
    w = inverse_shuffle(w)
    # undo xor
    w = [w[i] ^ C2[i] for i in range(4)]
    return w  # == rotl64(w_in[i], rot[i]) for each i


def parse_testvectors(path):
    pairs = []
    with open(path) as f:
        lines = f.readlines()
    i = 0
    while i < len(lines):
        if lines[i].startswith("#"):
            i += 1  # skip "#N"
            i += 1  # skip "input"
            w_in = [int(x, 16) for x in lines[i].split()]
            i += 1
            i += 1  # skip "output"
            w_out = [int(x, 16) for x in lines[i].split()]
            i += 1
            pairs.append((w_in, w_out))
        else:
            i += 1
    return pairs


pairs = parse_testvectors("testvector.txt")
print(f"Loaded {len(pairs)} test vectors\n")

# 역산: after_rotate[j][i] = rotl64(pairs[j][0][i], rot[i])
after_rotate = [undo_round(w_out) for _, w_out in pairs]

rot = []
for wi in range(4):
    found = None
    for r in range(64):
        if all(rotl64(pairs[j][0][wi], r) == after_rotate[j][wi] for j in range(len(pairs))):
            found = r
            break
    if found is None:
        print(f"rot[{wi}]: 해당하는 값 없음")
        rot.append(0)
    else:
        print(f"rot[{wi}] = {found}")
        rot.append(found)

print(f"\nconst unsigned int rot[4] = {{ {rot[0]}, {rot[1]}, {rot[2]}, {rot[3]} }};")
