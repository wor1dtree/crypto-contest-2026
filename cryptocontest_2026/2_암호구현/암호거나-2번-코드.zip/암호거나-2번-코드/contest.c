#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef __AVX2__
#include <immintrin.h>
#endif

typedef struct {
    uint64_t w[4];
} state256_t;

/* -------------------------------------------------
 * Utility functions
 * ------------------------------------------------- */
static inline uint64_t rotl64(uint64_t x, unsigned int n) {
    n &= 63;
    if (n == 0) return x;
    return (x << n) | (x >> (64 - n));
}

void print_state256(const char *label, const state256_t *state) {
    printf("%s = %016llx %016llx %016llx %016llx\n",
           label,
           (unsigned long long)state->w[0],
           (unsigned long long)state->w[1],
           (unsigned long long)state->w[2],
           (unsigned long long)state->w[3]);
}

/* -------------------------------------------------
 * Sub-operations
 * ------------------------------------------------- */

/* 64-bit wise rotation */
void rotate_words_left_64wise(state256_t *state, const unsigned int rot[4]) {
    for (int i = 0; i < 4; i++) {
        state->w[i] = rotl64(state->w[i], rot[i]);
    }
}

/* 256-bit wise XOR */
void xor_constants_256wise(state256_t *state, const uint64_t constants2[4]) {
    for (int i = 0; i < 4; i++) {
        state->w[i] ^= constants2[i];
    }
}

/* 8-bit wise shuffle: out[i] = in[shuffle_map[i]] */
void shuffle_bytes_256(state256_t *state, const uint8_t shuffle_map[32]) {
    uint8_t in[32];
    uint8_t out[32];

    memcpy(in, state, 32);

    for (int i = 0; i < 32; i++) {
        out[i] = in[shuffle_map[i] & 31];
    }

    memcpy(state, out, 32);
}

/* 64-bit wise add */
void add_constants_64wise(state256_t *state, const uint64_t constants1[4]) {
    for (int i = 0; i < 4; i++) {
        state->w[i] += constants1[i];
    }
}

/* -------------------------------------------------
 * 1) One-round permutation:
 *    rotation -> XOR -> shuffling -> add
 *    (uses a fixed reverse-byte shuffle internally)
 * ------------------------------------------------- */
void permute_one_round(state256_t *state,
                       const unsigned int rot[4],
                       const uint8_t shuffle_map[32],
                       const uint64_t constants2[4],
                       const uint64_t constants1[4]) {
     rotate_words_left_64wise(state, rot);
     xor_constants_256wise(state, constants2);
     shuffle_bytes_256(state, shuffle_map);
     add_constants_64wise(state, constants1);
}

#ifdef __AVX2__
__attribute__((target("avx2")))
static void permute_20rounds_avx2(state256_t *state,
                                   const unsigned int rot[4],
                                   const uint64_t constants2[4],
                                   const uint64_t constants1[4]) {
    __m256i s = _mm256_loadu_si256((const __m256i *)state);

    /* rotation amounts: lane i = rot[i] */
    const __m256i vrotl = _mm256_set_epi64x((long long)rot[3], (long long)rot[2],
                                            (long long)rot[1], (long long)rot[0]);
    const __m256i vrotr = _mm256_set_epi64x((long long)(64 - rot[3]), (long long)(64 - rot[2]),
                                            (long long)(64 - rot[1]), (long long)(64 - rot[0]));
    /* reversed rotation amounts: lane i = rot[3-i] */
    const __m256i vrotl_r = _mm256_set_epi64x((long long)rot[0], (long long)rot[1],
                                              (long long)rot[2], (long long)rot[3]);
    const __m256i vrotr_r = _mm256_set_epi64x((long long)(64 - rot[0]), (long long)(64 - rot[1]),
                                              (long long)(64 - rot[2]), (long long)(64 - rot[3]));

    /* constants: lane i = c[i] */
    const __m256i vc2 = _mm256_loadu_si256((const __m256i *)constants2);
    const __m256i vc1 = _mm256_loadu_si256((const __m256i *)constants1);
    /* reversed constants: lane i = c[3-i] */
    const __m256i vc2_r = _mm256_set_epi64x((long long)constants2[0], (long long)constants2[1],
                                            (long long)constants2[2], (long long)constants2[3]);
    const __m256i vc1_r = _mm256_set_epi64x((long long)constants1[0], (long long)constants1[1],
                                            (long long)constants1[2], (long long)constants1[3]);

    /* byte-swap mask: reverses the 8 bytes within each 64-bit element */
    const __m256i bswap = _mm256_set_epi8(
        8,9,10,11,12,13,14,15,  0,1,2,3,4,5,6,7,
        8,9,10,11,12,13,14,15,  0,1,2,3,4,5,6,7);

    /* 20 rounds = 10 double-rounds */
    #pragma GCC unroll 10
    for (int i = 0; i < 10; i++) {
        /* sub-round 2k:    rotate(rot)     -> xor(c2)     -> bswap -> add(rev c1) */
        s = _mm256_or_si256(_mm256_sllv_epi64(s, vrotl), _mm256_srlv_epi64(s, vrotr));
        s = _mm256_xor_si256(s, vc2);
        s = _mm256_shuffle_epi8(s, bswap);
        s = _mm256_add_epi64(s, vc1_r);
        /* sub-round 2k+1:  rotate(rev rot) -> xor(rev c2) -> bswap -> add(c1) */
        s = _mm256_or_si256(_mm256_sllv_epi64(s, vrotl_r), _mm256_srlv_epi64(s, vrotr_r));
        s = _mm256_xor_si256(s, vc2_r);
        s = _mm256_shuffle_epi8(s, bswap);
        s = _mm256_add_epi64(s, vc1);
    }

    _mm256_storeu_si256((__m256i *)state, s);
}
#endif /* __AVX2__ */

/* -------------------------------------------------
 * 2) 20-round permutation
 *    uses the same constants1/constants2 for all rounds
 * ------------------------------------------------- */
void permute_20rounds(state256_t *state,
                     const unsigned int rot[4],
                      const uint8_t shuffle_map[32],
                     const uint64_t constants1[4],
                     const uint64_t constants2[4]) {
    for (int r = 0; r < 20; r++) {
#ifdef __AVX2__
        (void)r; (void)shuffle_map;
        permute_20rounds_avx2(state, rot, constants2, constants1); break;
#else
        permute_one_round(state, rot, shuffle_map, constants2, constants1);
#endif
    }
}

/* -------------------------------------------------
 * 3) Main: test + timing
 * ------------------------------------------------- */
int main(void) {
    /* one-round test parameters */
    // TODO: Set rot to proper values.
    const unsigned int rot[4] = { 43, 7, 29, 14 };

    uint8_t shuffle_map[32];
    for (int i = 0; i < 32; i++) {
        shuffle_map[i] = (uint8_t)(31 - i);
    }

    uint64_t constants1[4] = {
        0x8f4a2c1e9b7d3f61ULL,
        0x3c6e9a1d5b7f2840ULL,
        0xa7e2d9c4b1f60853ULL,
        0x5d0f3a8e2c6b4197ULL
    };

    uint64_t constants2[4] = {
        0xe7b92d4a6c1f8035ULL,
        0x1a4f8c3e9d2b6074ULL,
        0xc3f05a2e8d6194b7ULL,
        0x6b2e9d1a4f7c3085ULL
    };

    printf("=== Test 1: one round I/O ===\n");
    /* verify the one-round testvectors in testvector.txt */
    {
        FILE *fv = fopen("testvector.txt", "r");
        if (!fv) {
            perror("fopen testvector.txt for read");
            return 1;
        }

        char line[64];
        int n = 0;
        int all_ok = 1;

        while (fgets(line, sizeof(line), fv)) {
            if (line[0] == '#') {
                unsigned long long in0, in1, in2, in3;
                unsigned long long out0, out1, out2, out3;

                if (!fgets(line, sizeof(line), fv)) break; /* "input" */
                if (fscanf(fv, "%llx %llx %llx %llx",
                           &in0, &in1, &in2, &in3) != 4) {
                    all_ok = 0;
                    break;
                }
                if (!fgets(line, sizeof(line), fv)) break; /* end of numbers line */
                if (!fgets(line, sizeof(line), fv)) break; /* "output" */
                if (fscanf(fv, "%llx %llx %llx %llx",
                           &out0, &out1, &out2, &out3) != 4) {
                    all_ok = 0;
                    break;
                }
                if (!fgets(line, sizeof(line), fv)) break; /* end of output numbers line */

        state256_t vin = { .w = { in0, in1, in2, in3 } };
        state256_t vout = vin;
        permute_one_round(&vout, rot, shuffle_map, constants2, constants1);

                if (vout.w[0] != out0 || vout.w[1] != out1 ||
                    vout.w[2] != out2 || vout.w[3] != out3) {
                    all_ok = 0;
                    break;
                }
                n++;
            }
        }
        fclose(fv);

        if (all_ok) {
            printf("one-round testvector verification: OK (%d pairs checked)\n\n", n);
        } else {
            printf("one-round testvector verification: MISMATCH\n\n");
        }
    }

    printf("=== Test 2: 20 rounds ===\n");

    /* verify the 20-round testvector from testvector_20round.txt */
    {
        FILE *fv20r = fopen("testvector_20round.txt", "r");
        if (!fv20r) {
            perror("fopen testvector_20round.txt for read");
            return 1;
        }

        char dummy[16];
        unsigned long long in0, in1, in2, in3;
        unsigned long long out0, out1, out2, out3;

        /* skip the 'input' line label */
        if (fscanf(fv20r, "%15s", dummy) != 1 ||
            fscanf(fv20r, "%llx %llx %llx %llx",
                   &in0, &in1, &in2, &in3) != 4 ||
            fscanf(fv20r, "%15s", dummy) != 1 ||  /* 'output' */
            fscanf(fv20r, "%llx %llx %llx %llx",
                   &out0, &out1, &out2, &out3) != 4) {
            fprintf(stderr, "Failed to parse testvector_20round.txt\n");
            fclose(fv20r);
            return 1;
        }
        fclose(fv20r);

        state256_t vin = { .w = { in0, in1, in2, in3 } };
        state256_t vout = vin;
        permute_20rounds(&vout, rot, shuffle_map, constants1, constants2);

        int ok = 1;
        if (vout.w[0] != out0 || vout.w[1] != out1 ||
            vout.w[2] != out2 || vout.w[3] != out3) {
            ok = 0;
        }

        if (ok) {
            printf("20-round testvector verification: OK\n\n");
        } else {
            printf("20-round testvector verification: MISMATCH\n\n");
        }
    }

    printf("=== Test 3: timing of 20-round permutation ===\n");
    {
        const int iterations = 1000000;
        state256_t bench = {
            .w = {
                0x0123456789abcdefULL,
                0xfedcba9876543210ULL,
                0x0f1e2d3c4b5a6978ULL,
                0x8877665544332211ULL
            }
        };

        clock_t start = clock();
        for (int i = 0; i < iterations; i++) {
            permute_20rounds(&bench, rot, shuffle_map, constants1, constants2);
        }
        clock_t end = clock();

        double elapsed_sec = (double)(end - start) / CLOCKS_PER_SEC;
        double per_call_us = (elapsed_sec * 1000000.0) / iterations;

        print_state256("benchmark final state", &bench);
        printf("iterations           = %d\n", iterations);
        printf("total elapsed time   = %.6f sec\n", elapsed_sec);
        printf("average per 20rounds = %.6f us\n", per_call_us);
    }

    return 0;
}