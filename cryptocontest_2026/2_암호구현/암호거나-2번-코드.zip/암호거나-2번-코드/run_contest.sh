#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

gcc -O3 -march=native -Wall -Wextra -o contest contest.c
./contest
