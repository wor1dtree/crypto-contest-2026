#pip install ortools
from ortools.sat.python import cp_model

SBOX = [
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16,
]

class Byte:
    def __init__(self, model, name, value=None):
        self.model = model
        if value is None:
            self.int = model.NewIntVar(0, 255, name)
            self.bits = [model.NewBoolVar(f"{name}_b{i}") for i in range(8)]
            model.Add(self.int == sum((1 << i) * self.bits[i] for i in range(8)))
        else:
            self.int = model.NewConstant(value)
            self.bits = []
            for i in range(8):
                b = model.NewBoolVar(f"{name}_{i}_{(value >> i) & 1}")
                model.Add(b == ((value >> i) & 1))
                self.bits.append(b)


def xor_bits(model, inputs, out):
    # out == xor(inputs)
    model.AddBoolXOr(list(inputs) + [out.Not()])


def byte_xor(model, name, *args):
    out = Byte(model, name)
    for i in range(8):
        xor_bits(model, [a.bits[i] for a in args], out.bits[i])
    return out


def xtime(model, name, x):
    out = Byte(model, name)
    # AES xtime: (x << 1) xor 0x1b if the old MSB is set.
    coeff = 0x1B
    xor_bits(model, [x.bits[7]] if (coeff & 1) else [], out.bits[0])
    for i in range(1, 8):
        inputs = [x.bits[i - 1]]
        if (coeff >> i) & 1:
            inputs.append(x.bits[7])
        xor_bits(model, inputs, out.bits[i])
    return out


def mul2(model, name, x):
    return xtime(model, name, x)


def mul3(model, name, x):
    return byte_xor(model, name, xtime(model, name + "_x2", x), x)


def sub_bytes(model, state, prefix):
    out = []
    table = [(i, SBOX[i]) for i in range(256)]
    for i, x in enumerate(state):
        y = Byte(model, f"{prefix}_sb{i}")
        model.AddAllowedAssignments([x.int, y.int], table)
        out.append(y)
    return out


def shift_rows(state):
    out = [None] * 16
    for r in range(4):
        row = [state[r + 4 * c] for c in range(4)]
        row = row[r:] + row[:r]
        for c in range(4):
            out[r + 4 * c] = row[c]
    return out


def mix_columns(model, state, prefix):
    out = [None] * 16
    for c in range(4):
        a0, a1, a2, a3 = [state[r + 4 * c] for r in range(4)]
        out[4 * c + 0] = byte_xor(model, f"{prefix}_mc{c}_0", mul2(model, f"{prefix}_m2_{c}_0", a0), mul3(model, f"{prefix}_m3_{c}_1", a1), a2, a3)
        out[4 * c + 1] = byte_xor(model, f"{prefix}_mc{c}_1", a0, mul2(model, f"{prefix}_m2_{c}_1", a1), mul3(model, f"{prefix}_m3_{c}_2", a2), a3)
        out[4 * c + 2] = byte_xor(model, f"{prefix}_mc{c}_2", a0, a1, mul2(model, f"{prefix}_m2_{c}_2", a2), mul3(model, f"{prefix}_m3_{c}_3", a3))
        out[4 * c + 3] = byte_xor(model, f"{prefix}_mc{c}_3", mul3(model, f"{prefix}_m3_{c}_0", a0), a1, a2, mul2(model, f"{prefix}_m2_{c}_3", a3))
    return out


def round_keys(model, k):
    perms = [
        list(range(16)),
        [5, 8, 6, 3, 15, 14, 13, 12, 11, 10, 2, 1, 0, 4, 7, 9],
        [6, 10, 5, 12, 3, 2, 15, 9, 1, 4, 8, 11, 13, 7, 0, 14],
        [10, 3, 1, 7, 8, 11, 9, 5, 2, 6, 12, 15, 4, 0, 14, 13],
        [14, 11, 7, 5, 10, 1, 13, 12, 0, 6, 2, 4, 8, 15, 3, 9],
        [15, 10, 12, 1, 14, 8, 13, 4, 2, 3, 0, 5, 11, 7, 6, 9],
        [1, 5, 7, 14, 15, 8, 0, 4, 9, 13, 3, 6, 12, 2, 10, 11],
    ]
    rks = []
    for i, p in enumerate(perms):
        rk = [k[j] for j in p]
        if i in {1, 2, 5, 6}:
            rk = mix_columns(model, rk, f"rk{i}")
        rks.append(rk)
    return rks


def add_round_key(model, state, rk, prefix):
    return [byte_xor(model, f"{prefix}_ark{i}", state[i], rk[i]) for i in range(16)]


def parse_leak(path):
    leak = {}
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if not line or ": " not in line:
            continue
        left, bits = line.split(": ")
        rnd = int(left.split("^")[1].split("[")[0])
        idx = int(left.split("[")[1].split("]")[0])
        leak[(rnd, idx)] = bits
    return leak


def encrypt(model, plain, rks):
    states = [[Byte(model, f"p{i}", b) for i, b in enumerate(plain)]]
    x = states[0]
    for r in range(7):
        y = sub_bytes(model, x, f"r{r}")
        z = shift_rows(y)
        w = mix_columns(model, z, f"r{r}")
        x = add_round_key(model, w, rks[r], f"r{r}")
        states.append(x)
    return states


def main():
    idx = 28178
    plain = open("plaintext.bin", "rb").read()[idx * 16:(idx + 1) * 16]
    cipher = open("ciphertext.bin", "rb").read()[idx * 16:(idx + 1) * 16]
    leak = parse_leak("leaked.txt")

    model = cp_model.CpModel()
    key = [Byte(model, f"K{i}") for i in range(16)]
    rks = round_keys(model, key)
    states = encrypt(model, plain, rks)

    for (rnd, idx), bits in leak.items():
        for pos, ch in enumerate(bits):
            if ch != "-":
                model.Add(states[rnd][idx].bits[7 - pos] == int(ch))
    for i, b in enumerate(cipher):
        model.Add(states[7][i].int == b)
    model.Add(key[0].int == 0x29)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 900
    solver.parameters.num_search_workers = 16
    solver.parameters.log_search_progress = True
    status = solver.Solve(model)
    print("status", solver.StatusName(status))
    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        rec = bytes(solver.Value(k.int) for k in key)
        print("key_hex =", rec.hex())


if __name__ == "__main__":
    main()