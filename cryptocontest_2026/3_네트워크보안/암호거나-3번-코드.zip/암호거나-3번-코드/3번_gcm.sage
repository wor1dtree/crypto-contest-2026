# 1. AES-GCM 유한체 및 다항식 링 정의
F.<a> = GF(2^128, name='a', modulus=x^128 + x^7 + x^2 + x + 1)
R.<H> = PolynomialRing(F)

def to_field(hex_str):
    """Hex 문자열을 GCM 표준 비트 순서(Leftmost-bit-first)로 변환"""
    b = bytes.fromhex(hex_str)
    bits = []
    for byte in b:
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return F(bits)

def from_field(element):
    """유한체 원소를 다시 Hex 문자열로 변환"""
    bits = element.list()
    bits += [0] * (128 - len(bits))
    res = []
    for i in range(0, 128, 8):
        byte_val = 0
        for j, bit in enumerate(bits[i:i+8]):
            if bit:
                byte_val |= (1 << (7 - j))
        res.append(byte_val)
    return bytes(res).hex()

def make_ghash_poly(hex_data):
    """블록 데이터를 H에 대한 다항식으로 변환"""
    blocks = [to_field(hex_data[i:i+32]) for i in range(0, len(hex_data), 32)]
    n = len(blocks)
    poly = R(0)
    for i, block in enumerate(blocks):
        poly += block * H^(n - i)
    return poly

# --- 데이터 입력 ---
pk1 = "00000000000000011703030022000000a99141d1d84c3df5b3c6e328f879f64b2bcd6561fe7fe19a73edad45cd0fb968f4f0000000000000000000000000000000000000000000680000000000000110"
pk2 = "00000000000000021703030032000000a99141d1d84c3df4afcdf677d263f31a7a8f2c70ad62f69a72eaa943dd56e42cf9f1e436ba7d1eb5ee2efe9b65522edc6860000000000000000000000000000000000000000000680000000000000190"
pk3 = "00000000000000031703030030000000a99141d1d84c3df6bfdcdb7dec7cf30462db203fbc36a29772edbf159643b468f5f1e520e7341daee867a49665542cd900000000000000680000000000000180"

pk12xor = to_field("9ace8a4cb803cd3131187cf5f737dbfe")
pk13xor = to_field("b38b345b0bc982a474048b8476a74aaa")
pk23xor = to_field("2945be17b3ca4f95451cf77181909154")

# --- 방정식 구성 (f(H) = GHASH_a + GHASH_b + tag_xor = 0) ---
f12 = make_ghash_poly(pk1) + make_ghash_poly(pk2) + pk12xor
f13 = make_ghash_poly(pk1) + make_ghash_poly(pk3) + pk13xor
f23 = make_ghash_poly(pk2) + make_ghash_poly(pk3) + pk23xor

# --- 근 찾기 및 시각화 ---
def get_roots_hex(poly):
    return {from_field(r) for r in poly.roots(multiplicities=False)}

roots12 = get_roots_hex(f12)
roots13 = get_roots_hex(f13)
roots23 = get_roots_hex(f23)

print("### [1] pk1-pk2 pair candidates ###")
for r in roots12: print(f" - {r}")

print("### [2] pk1-pk3 pair candidates ###")
for r in roots13: print(f" - {r}")

print("### [3] pk2-pk3 pair candidates ###")
for r in roots23: print(f" - {r}")

# --- 공통 집합(교집합) 찾기 ---
common_roots = roots12.intersection(roots13).intersection(roots23)

print("\n" + "="*40)
if not common_roots:
    print("[!] No common candidate found. Check data consistency.")
else:
    print(f"[+] Final Common Candidate for H ({len(common_roots)} found):")
    for r in common_roots:
        print(f" >> {r}")
print("="*40)