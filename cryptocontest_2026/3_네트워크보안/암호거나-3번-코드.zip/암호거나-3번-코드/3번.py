from dataclasses import dataclass

PACKETS_HEX = [
    "170303003a9c269a9f29810ab0a99141d1d84c3df5b3c6e328f879f64b2bcd6561fe7fe19a73edad45cd0fb968f4f0035dd4f7202b87c66b7a2f2442f6d53f",
    "170303004a9c269a9f29810ab0a99141d1d84c3df4afcdf677d263f31a7a8f2c70ad62f69a72eaa943dd56e42cf9f1e436ba7d1eb5ee2efe9b65522edc686099935ebb98284af75a6253d1b5c10ec1",
    "17030300489c269a9f29810ab0a99141d1d84c3df6bfdcdb7dec7cf30462db203fbc36a29772edbf159643b468f5f1e520e7341daee867a49665542cd9b0d6e0ac2be205621f7ea4a034519f95"
]


@dataclass
class TLSRecord:
    content_type: int
    version: bytes
    length: int
    nonce: bytes
    ct: bytes
    tag: bytes


def parse_packet(pk_hex: str) -> TLSRecord:
    data         = bytes.fromhex(pk_hex)
    content_type = data[0]
    version      = data[1:3]
    length       = int.from_bytes(data[3:5], 'big')
    payload      = data[5:]
    nonce        = payload[:8]
    tag          = payload[-16:]
    ct           = payload[8:-16]
    return TLSRecord(content_type, version, length, nonce, ct, tag)


def xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


def pad16(data: bytes) -> bytes:
    r = len(data) % 16
    return data + b'\x00' * (16 - r) if r else data


def build_aad(p: TLSRecord, seq_num: int) -> bytes:
    # TLS 순서: Finished(seq=0) → AppData(seq=1, 2, 3, ...)
    return (
        seq_num.to_bytes(8, 'big')
        + bytes([p.content_type])
        + p.version
        + len(p.ct).to_bytes(2, 'big')
    )


def ghash_input(aad: bytes, ct: bytes) -> bytes:
    """GHASH 입력: pad(AAD) || pad(C) || len64(AAD) || len64(C)"""
    len_block = (len(aad) * 8).to_bytes(8, 'big') + (len(ct) * 8).to_bytes(8, 'big')
    return pad16(aad) + pad16(ct) + len_block


# ── 패킷 파싱 ─────────────────────────────────────────────────────────────────
packets = [parse_packet(pk) for pk in PACKETS_HEX]

# ── Tag XOR ───────────────────────────────────────────────────────────────────
t1, t2, t3 = (p.tag for p in packets)
print("\n--- tag XOR ---")
print(f"  T1 ^ T2 : {xor_bytes(t1, t2).hex()}")
print(f"  T1 ^ T3 : {xor_bytes(t1, t3).hex()}")
print(f"  T2 ^ T3 : {xor_bytes(t2, t3).hex()}")

# ── GHASH 입력 분석 ────────────────────────────────────────────────────────────
print("\n--- GHASH 입력값 ---")
for i, p in enumerate(packets):
    seq_num  = i + 1
    aad      = build_aad(p, seq_num)
    ghash_in = ghash_input(aad, p.ct)
    print(f"  pk{i+1} (seq={seq_num}): {ghash_in.hex()[:32]}...{ghash_in.hex()[-32:]}")

# ── KS_1 연산 ────────────────────────────────────────────────────────────
def ghash_multiply(x: int, y: int) -> int:
    """GF(2^128)에서의 곱셈 (GCM 표준 방식)"""
    res = 0
    # GCM의 reduction polynomial: x^128 + x^7 + x^2 + x + 1
    # 하위 비트부터 처리하는 구조이므로 0xE1... 값을 사용함
    R = 0xE1000000000000000000000000000000
    
    for i in range(128):
        if (x >> (127 - i)) & 1:
            res ^= y
        if y & 1:
            y = (y >> 1) ^ R
        else:
            y >>= 1
    return res

def Ghash(ghash_in: bytes, H_bytes: bytes) -> bytes:
    """
    GHASH(H, A, C) 연산
    X_i = (X_{i-1} ^ B_i) * H
    """
    H = int.from_bytes(H_bytes, 'big')
    X = 0
    
    # 16바이트(128비트) 블록 단위로 처리
    for i in range(0, len(ghash_in), 16):
        block = int.from_bytes(ghash_in[i:i+16], 'big')
        X ^= block
        X = ghash_multiply(X, H)
        
    return X.to_bytes(16, 'big')

print("\n--- KS_1 연산 ---")
H = bytes.fromhex("112332a84132bc0c5c23a61037723683")
for i, p in enumerate(packets):
    seq_num  = i + 1
    aad      = build_aad(p, seq_num)
    ghash_in = ghash_input(aad, p.ct)
    print(xor_bytes(p.tag, Ghash(ghash_in, H)).hex())

# ── 최종 위조 코드 ────────────────────────────────────────────────────────────
KS = bytes.fromhex("1e023d8461003896981f1441c5feab90")

p = packets[2]
delta = b"\x00" * 32 + b"\x04" + b'\x00' * 15
p.ct = xor_bytes(p.ct, delta)
seq_num = 3
aad     = build_aad(p, seq_num)
ghash_in = ghash_input(aad, p.ct)
p.tag = xor_bytes(Ghash(ghash_in, H), KS)
print(f"{p.content_type:02x}", end="")
print(f"{(p.version).hex()}", end="")
print(f"{p.length:04x}", end="")
print(f"{(p.nonce).hex()}", end="")
print(f"{(p.ct).hex()}", end="")
print(f"{(p.tag).hex()}", end="")